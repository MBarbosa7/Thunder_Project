from django.shortcuts import render
import requests

def calculadora(request):
    return render(request, 'calculadora.html')

def calcular(request):
    if request.method == 'POST':
        city = request.POST['city']
        num1 = 1
        num2 = 2
        resultado = 0
        resultado = num1 + num2
   
        API_KEY = 'dd770c9d0d8cf26630d523974a121c46' #Chave da API
        linguagem = "pt_br" #Linguagem dos Resultados
        link = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&lang={linguagem}'

        req = requests.get(link)
        req.dic = req.json()
        clima = req.dic['weather'][0]['description']
        temp_maxima = req.dic['main']['temp_max'] - 273.15
        temp_minima = req.dic['main']['temp_min'] - 273.15
        temperatura = req.dic['main']['temp'] - 273.15
        sensacao = req.dic['main']['feels_like'] - 273.15
        humidade = req.dic['main']['humidity']

        return render(request, 'calculadora.html', {'resultado': resultado, 'clima': clima, 'temp_maxima':temp_maxima,
                                                    'temp_minima': temp_minima, 'temperatura': temperatura,
                                                    'sensacao': sensacao, 'humidade': humidade})
